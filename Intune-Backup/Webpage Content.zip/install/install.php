<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<link rel="stylesheet" href="install.css" type="text/css">
</head>
<body>
<div id="container">

<div class="content2">
<div id="installbox">

<div id="installtitle">
<h5>Website Settings</h5>
</div>
<div id="installleft">
<form method="post" action="install2.php" enctype="multipart/form-data">
<table>
  <tr>
    <td>Password:</td>
    <td><input name="password"></td>
  </tr>
  <tr>
    <td>Email Address</td>
    <td><input name="email"></td>
  </tr>
  </table>

</div>

<input type="submit" value="        Install        "></form>
<FORM METHOD="LINK" ACTION="database.php">
<input type="submit" value="        Back        "></FORM>
</div>
</div>
</div>
</div>
 </body>