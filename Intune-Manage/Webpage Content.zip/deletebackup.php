<?php
/**
 * This file is part of a GPL-licensed project.
 *
 * Copyright (C) 2024 Andrew Taylor (andrew.taylor@andrewstaylor.com)
 * A special thanks to David at Codeshack.io for the basis of the login system!
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://github.com/andrew-s-taylor/public/blob/main/LICENSE>.
 */
?>
<?php
include 'main.php';
// Check logged-in
check_loggedin($con);
// output message (errors, etc)
$msg = '';

if (isset($_POST['tenantid'])) {
$tenantid2 = $_POST['tenantid'];
$customerid = $_POST['customerid'];
    // Retrieve additional account info from the database because we don't have them stored in sessions
$stmt = $con->prepare('SELECT reponame, golden FROM accounts WHERE id = ?');
// In this case, we can use the account ID to retrieve the account info.
$stmt->bind_param('i', $customerid);
$stmt->execute();
$stmt->bind_result($reponame, $golden);
$stmt->fetch();
$stmt->close();

//Check every database item is present
$checkbox1=$_POST['policy'];  
//Add each checkbox submitted to the $chk variable
foreach($checkbox1 as $chk1)  
   {  

    $auditlog_userID = $_SESSION['id'];
    $auditlog_ipAddress = $_SERVER['REMOTE_ADDR'];
    $auditlog_timestamp = date('Y-m-d H:i:s');
    $auditlog_message = "Backup $chk1 deleted on tenant $tenantid2";
    $stmt = $con->prepare('INSERT INTO auditlog (UserID, IPAddress, Timestamp, Task) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('isss', $auditlog_userID, $auditlog_ipAddress, $auditlog_timestamp, $auditlog_message);
    $stmt->execute();
    $stmt->close();

//Check What Git is being used
if ($gittype == "github") {

//GitHub Repo
			//Github Details
$githubowner = $repoowner;
$githubrepo = $reponame;
$githubtoken = $gittoken;


// Authenticate with GitHub using a personal access token
$authentication = base64_encode("$githubowner:$githubtoken");


// Set up the request headers
$headers = [
  "Authorization: Basic $authentication",
  'Accept: application/vnd.github+json',
  "User-Agent: ManageIntune"
];

//Get the SHA
$sha3 = file_get_contents("https://api.github.com/repos/$githubowner/$githubrepo/contents/$chk1?ref=main", false, stream_context_create([
  'http' => [
    'method' => 'GET',
    'header' => $headers
  ]
]));

$sha2 = json_decode($sha3, true);
$sha = $sha2['sha'];
// Set up the cURL options to delete the file include sha and message
$options = [
  CURLOPT_URL => "https://api.github.com/repos/$githubowner/$githubrepo/contents/$chk1",
  CURLOPT_HTTPHEADER => $headers,
  CURLOPT_CUSTOMREQUEST => 'DELETE',
  CURLOPT_RETURNTRANSFER => 'true',
  CURLOPT_POSTFIELDS => '{"message": "Deleted by IntuneBackup", "sha": "'.$sha.'"}'
];


// Initialize the cURL session
$curl = curl_init();
curl_setopt_array($curl, $options);
$result = curl_exec($curl);
// Close the cURL session
curl_close($curl);
}

if ($gittype == "gitlab") {

	//GitLab Repo
				//GitLab Details
	$gitprojectid = $gitproject;
	$gitlabtoken = $gittoken;
	

	// Set up the request headers
	$headers = [
		"PRIVATE-TOKEN:  $gitlabtoken"
	];

    //Convert $chk1 to URL-encoded
    $chk1 = urlencode($chk1);
	
	// Set up the cURL options to delete the file
    $options = [
      CURLOPT_URL => "https://gitlab.com/api/v4/projects/$gitprojectid/repository/files/$chk1",
      CURLOPT_HTTPHEADER => $headers,
      CURLOPT_CUSTOMREQUEST => 'DELETE',
      CURLOPT_RETURNTRANSFER => 'true',
      CURLOPT_POSTFIELDS => '{"branch": "main", "commit_message": "Deleted by IntuneBackup"}'
    ];
	
	// Initialize the cURL session
	$curl = curl_init();
	curl_setopt_array($curl, $options);
	$result = curl_exec($curl);
// Close the cURL session
curl_close($curl);
	}

if ($gittype == "azure") {
	$org = $repoowner;
$repo = $reponame;
$project = $gitproject;
$token = $gittoken;

// Set up the request headers
$headers = array(
    "Content-Type:application/json",
    "Authorization: Basic ".base64_encode(":".$token)
);

$options = [
    CURLOPT_URL => "https://dev.azure.com/$org/$project/_apis/git/repositories/$repo/items?scopepath=/&recursionLevel=Full&includeContentMetadata=true&api-version=7.1-preview.1&version=master",
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_RETURNTRANSFER => 'true',
  ];
  // Initialize the cURL session
  $curl = curl_init();
  curl_setopt_array($curl, $options);
  $result2 = curl_exec($curl);
  // Close the cURL session
  curl_close($curl);

    ////Look through the array to find this file
    //Decode the json
        $decodedcommit2 = json_decode($result2, true);
        $decodedcommit3 = $decodedcommit2['value'];
        foreach ($decodedcommit3 as $decodedcommit4) {
            $decodedcommit5 = $decodedcommit4['path'];
            if ($decodedcommit5 == $chk1) {
                $sha3 = $decodedcommit4['commitId'];
            }
        }

// Get the object ID of the latest commit on 'refs/heads/master'
$options = [
    CURLOPT_URL => "https://dev.azure.com/$org/$project/_apis/git/repositories/$repo/refs?filter=heads/master&api-version=6.0",
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_RETURNTRANSFER => 'true'
  ];
  $curl = curl_init();
  curl_setopt_array($curl, $options);
  $result3 = curl_exec($curl);
  curl_close($curl);
  $decodedcommit6 = json_decode($result3, true);

    $latestCommitObjectId = $decodedcommit6['value'][0]['objectId'];


  
  // Set up the cURL options to delete the file using a POST request for a new commit with the changeType as delete using the object ID
  $options = [
    CURLOPT_URL => "https://dev.azure.com/$org/$project/_apis/git/repositories/$repo/pushes?api-version=6.0",
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_RETURNTRANSFER => 'true',
    CURLOPT_POSTFIELDS => '{"refUpdates": [{"name": "refs/heads/master","oldObjectId": "'.$latestCommitObjectId.'"}],"commits": [{"comment": "Deleted by IntuneBackup","changes": [{"changeType": "delete","item": {"path": "'.$chk1.'"}}]}]}'
  ];
  $curl = curl_init();
  curl_setopt_array($curl, $options);
  $result = curl_exec($curl);
  curl_close($curl);

   }  
   }
   header('Location: home.php?updatemessage=File Deleted');
}
else {
    header("Location: manage-backups1.php");
}
?>