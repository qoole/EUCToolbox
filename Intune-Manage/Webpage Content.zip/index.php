<!DOCTYPE html>
<html>
<body>

<h1>Hello World</h1>

<?php
echo "Hello World!";
?>

</body>
</html>