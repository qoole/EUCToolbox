#!/bin/bash
echo "Bypassing oryx"